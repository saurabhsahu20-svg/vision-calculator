package com.vision.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.DecimalFormat
import java.time.LocalDate
import java.time.Period
import kotlin.math.*

private val android.content.Context.dataStore by preferencesDataStore(name = "vision_calc")
private val Navy = Color(0xFF071426)
private val Blue = Color(0xFF147DCE)
private val Silver = Color(0xFFDCE7F2)
private val Panel = Color(0xFF132941)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VisionApp() }
    }
}

@Composable
fun VisionApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var dark by remember { mutableStateOf(true) }
    var mode by remember { mutableStateOf("Basic") }
    var expression by remember { mutableStateOf("0") }
    var result by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(listOf<String>()) }
    var showHistory by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var memory by remember { mutableDoubleStateOf(0.0) }
    var angleMode by remember { mutableStateOf("DEG") }

    LaunchedEffect(Unit) {
        val saved = context.dataStore.data.first()[stringPreferencesKey("history")] ?: "[]"
        history = runCatching {
            val a = JSONArray(saved); (0 until a.length()).map { a.getString(it) }
        }.getOrDefault(emptyList())
    }

    val bg = if (dark) Navy else Color(0xFFF2F6FB)
    val fg = if (dark) Color.White else Color(0xFF102238)
    val panel = if (dark) Panel else Color.White
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Blue, background = bg) else lightColorScheme(primary = Blue, background = bg)) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bg, if (dark) Color(0xFF0D2742) else Color(0xFFE1EDF8)))).padding(16.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("VISION", color = Blue, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
                    Text("CALCULATOR", color = fg, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("Calculate Smart. Calculate Fast.", color = if (dark) Silver else Color.DarkGray, fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { showHistory = true }) { Text("HISTORY", color = fg, fontSize = 11.sp) }
                    TextButton(onClick = { dark = !dark }) { Text(if (dark) "☀" else "☾", color = fg, fontSize = 20.sp) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Basic", "Scientific", "Tools").forEach { tab ->
                    Button(onClick = { mode = tab; showTools = tab == "Tools" }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = if (mode == tab) Blue else panel),
                        shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(vertical = 11.dp)) {
                        Text(tab, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(Modifier.fillMaxWidth().weight(1f, fill = false), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.Bottom) {
                    Text(if (expression == "0") " " else expression, color = if (dark) Silver else Color.Gray, fontSize = 20.sp, textAlign = TextAlign.End, maxLines = 2)
                    Spacer(Modifier.height(10.dp))
                    Text(result.ifBlank { "0" }, color = fg, fontSize = 38.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, maxLines = 2)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ANGLE: $angleMode", color = Blue, fontSize = 10.sp, modifier = Modifier.clickable { angleMode = if (angleMode == "DEG") "RAD" else "DEG" })
                        Text("M = ${fmt(memory)}", color = Blue, fontSize = 10.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            if (showTools) {
                ToolPanel(fg = fg, panel = panel, onResult = { expression = it.first; result = it.second })
            } else {
                val keys = if (mode == "Scientific") {
                    listOf(
                        listOf("sin","cos","tan","log","ln"),
                        listOf("√","x²","x³","^","!"),
                        listOf("π","e","(",")","÷"),
                        listOf("7","8","9","DEL","×"),
                        listOf("4","5","6","AC","−"),
                        listOf("1","2","3","%","+"),
                        listOf("±","0",".","M+","=")
                    )
                } else {
                    listOf(
                        listOf("AC","DEL","%","÷"),
                        listOf("7","8","9","×"),
                        listOf("4","5","6","−"),
                        listOf("1","2","3","+"),
                        listOf("±","0",".","=")
                    )
                }
                keys.forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { key ->
                            val accent = key in listOf("AC","DEL","%","÷","×","−","+","=","sin","cos","tan","log","ln","√","x²","x³","^","!")
                            Button(onClick = {
                                when (key) {
                                    "AC" -> { expression = "0"; result = "" }
                                    "DEL" -> { expression = if (expression.length <= 1) "0" else expression.dropLast(1); result = "" }
                                    "=" -> {
                                        runCatching { evaluate(expression, angleMode) }.onSuccess {
                                            result = fmt(it)
                                            val entry = "$expression = $result  •  ${java.time.LocalDateTime.now().toString().replace('T',' ')}"
                                            history = (listOf(entry) + history).take(100)
                                            scope.launch { context.dataStore.edit { p -> p[stringPreferencesKey("history")] = JSONArray(history).toString() } }
                                        }.onFailure { result = "Error" }
                                    }
                                    "±" -> { expression = if (expression.startsWith("-")) expression.drop(1) else "-($expression)"; result = "" }
                                    "M+" -> { memory += result.toDoubleOrNull() ?: runCatching { evaluate(expression, angleMode) }.getOrDefault(0.0) }
                                    "π" -> expression = append(expression, "pi")
                                    "e" -> expression = append(expression, "e")
                                    "√" -> expression = append(expression, "sqrt(")
                                    "x²" -> expression = append(expression, "^2")
                                    "x³" -> expression = append(expression, "^3")
                                    "sin","cos","tan","log","ln" -> expression = append(expression, "$key(")
                                    else -> expression = append(expression, key)
                                }
                            }, modifier = Modifier.weight(1f).height(if (mode == "Scientific") 48.dp else 58.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = if (accent) Blue.copy(alpha = if (dark) .9f else 1f) else panel)) {
                                Text(key, fontSize = if (key.length > 2) 13.sp else 20.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                            }
                        }
                    }
                    Spacer(Modifier.height(7.dp))
                }
                if (mode == "Scientific") {
                    Text("M+ adds the current result to memory. Tap DEG/RAD to change angle units.", color = if (dark) Silver else Color.Gray, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("VISION CALCULATOR  •  OFFLINE", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = if (dark) Silver.copy(alpha=.6f) else Color.Gray, fontSize = 9.sp, letterSpacing = 1.5.sp)
        }
        if (showHistory) {
            AlertDialog(onDismissRequest = { showHistory = false }, containerColor = panel,
                title = { Text("Calculation History", color = fg) },
                text = {
                    Column {
                        if (history.isEmpty()) Text("No calculations yet.", color = fg)
                        LazyColumn(Modifier.heightIn(max = 360.dp)) {
                            items(history) { item -> Text(item, color = fg, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().clickable {
                                val parts = item.split(" = ")
                                if (parts.isNotEmpty()) { expression = parts[0]; result = "" ; showHistory = false }
                            }.padding(vertical = 8.dp)) }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { history = emptyList(); scope.launch { context.dataStore.edit { it[stringPreferencesKey("history")] = "[]" } } }) { Text("CLEAR", color = Blue) } },
                dismissButton = { TextButton(onClick = { showHistory = false }) { Text("CLOSE", color = Blue) } })
        }
    }
}

private fun append(old: String, key: String): String = if (old == "0" && key !in listOf(".", "+", "-", "×", "÷")) key else old + key

private fun fmt(v: Double): String {
    if (!v.isFinite()) return "Error"
    if (abs(v) < 1e12 && abs(v) >= 1e-8 && v == v.toLong().toDouble()) return DecimalFormat("#,##0").format(v)
    return BigDecimal(v.toString()).round(MathContext(10, RoundingMode.HALF_UP)).stripTrailingZeros().toPlainString()
}

/* Small recursive-descent expression evaluator. Supports arithmetic, parentheses,
   exponentiation, unary signs, percent, constants and scientific functions. */
private class Parser(private val s: String, private val angle: String) {
    private var i = 0
    private fun skip() { while (i < s.length && s[i].isWhitespace()) i++ }
    private fun eat(c: Char): Boolean { skip(); if (i < s.length && s[i] == c) { i++; return true }; return false }
    fun parse(): Double { val v = expr(); skip(); require(i == s.length) { "Unexpected input" }; return v }
    private fun expr(): Double { var x = term(); while (true) { x = when { eat('+') -> x + term(); eat('-') -> x - term(); else -> return x } } }
    private fun term(): Double { var x = power(); while (true) { x = when { eat('*') || eat('×') -> x * power(); eat('/') || eat('÷') -> x / power(); else -> return x } } }
    private fun power(): Double { var x = unary(); if (eat('^')) x = x.pow(power()); return x }
    private fun unary(): Double { if (eat('+')) return unary(); if (eat('-')) return -unary(); var x = atom(); if (eat('%')) x /= 100.0; if (eat('!')) x = factorial(x); return x }
    private fun atom(): Double {
        skip()
        if (eat('(')) { val x = expr(); require(eat(')')) { "Missing )" }; return x }
        if (i < s.length && (s[i].isDigit() || s[i] == '.')) {
            val start = i; while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            return s.substring(start, i).toDouble()
        }
        val start = i
        while (i < s.length && s[i].isLetter()) i++
        val name = s.substring(start, i).lowercase()
        return when (name) {
            "pi" -> Math.PI
            "e" -> Math.E
            "sqrt" -> sqrt(argument())
            "sin" -> trig(argument()) { sin(it) }
            "cos" -> trig(argument()) { cos(it) }
            "tan" -> trig(argument()) { tan(it) }
            "log" -> log10(argument())
            "ln" -> ln(argument())
            else -> error("Unknown function: $name")
        }
    }
    private fun argument(): Double { require(eat('(')) { "Function needs (" }; val x = expr(); require(eat(')')) { "Missing )" }; return x }
    private fun trig(x: Double, f: (Double)->Double) = f(if (angle == "DEG") Math.toRadians(x) else x)
}
private fun factorial(x: Double): Double {
    require(x >= 0 && x <= 170 && x % 1.0 == 0.0) { "Factorial requires integer 0..170" }
    var r = 1.0; for (n in 2..x.toInt()) r *= n; return r
}
private fun evaluate(s: String, angle: String): Double = Parser(s.replace(" ", "").replace("−","-").replace("×","*").replace("÷","/"), angle).parse()

@Composable
private fun ToolPanel(fg: Color, panel: Color, onResult: (Pair<String,String>) -> Unit) {
    var selected by remember { mutableStateOf("Percentage") }
    var a by remember { mutableStateOf("") }; var b by remember { mutableStateOf("") }; var c by remember { mutableStateOf("") }
    val tools = listOf("Percentage","GST (India)","Discount","Age","EMI","Simple Interest","Compound Interest","Date Difference","Unit Converter")
    Column(Modifier.fillMaxWidth().weight(1f).background(panel, RoundedCornerShape(20.dp)).padding(14.dp)) {
        Text("QUICK CALCULATORS", color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(tools) { item ->
                Text(item, color = fg, modifier = Modifier.fillMaxWidth().clickable { selected = item; a=""; b=""; c="" }.background(if (selected == item) Blue.copy(alpha=.18f) else Color.Transparent, RoundedCornerShape(8.dp)).padding(9.dp), fontSize = 13.sp)
            }
        }
        Text(selected, color = fg, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        val labels = when(selected) {
            "Percentage" -> listOf("Percentage (%)","Number")
            "GST (India)" -> listOf("Amount (₹)","GST rate (%)")
            "Discount" -> listOf("Original price (₹)","Discount (%)")
            "Age" -> listOf("Date of birth (YYYY-MM-DD)","")
            "EMI" -> listOf("Loan amount (₹)","Annual interest (%)","Months")
            "Simple Interest","Compound Interest" -> listOf("Principal (₹)","Annual interest (%)","Years")
            "Date Difference" -> listOf("Start date (YYYY-MM-DD)","End date (YYYY-MM-DD)")
            else -> listOf("Value","")
        }
        OutlinedTextField(a, { a=it }, label={ Text(labels[0]) }, singleLine=true, modifier=Modifier.fillMaxWidth())
        if (labels.size > 1 && labels[1].isNotBlank()) OutlinedTextField(b, { b=it }, label={ Text(labels[1]) }, singleLine=true, modifier=Modifier.fillMaxWidth())
        if (labels.size > 2) OutlinedTextField(c, { c=it }, label={ Text(labels[2]) }, singleLine=true, modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            val answer = runCatching {
                when(selected) {
                    "Percentage" -> "${a.toDouble()*b.toDouble()/100.0}"
                    "GST (India)" -> { val amount=a.toDouble(); val rate=b.toDouble(); "GST: ₹${amount*rate/100} | Total: ₹${amount*(1+rate/100)}" }
                    "Discount" -> { val price=a.toDouble(); val d=b.toDouble(); "Saving: ₹${price*d/100} | Final: ₹${price*(1-d/100)}" }
                    "Age" -> { val p=Period.between(LocalDate.parse(a), LocalDate.now()); "${p.years} years, ${p.months} months, ${p.days} days" }
                    "EMI" -> { val p=a.toDouble(); val r=b.toDouble()/1200; val n=c.toDouble(); val emi=if(r==0.0)p/n else p*r*(1+r).pow(n)/((1+r).pow(n)-1); "Monthly EMI: ₹${fmt(emi)}" }
                    "Simple Interest" -> { val p=a.toDouble(); val r=b.toDouble(); val t=c.toDouble(); "Interest: ₹${p*r*t/100} | Total: ₹${p*(1+r*t/100)}" }
                    "Compound Interest" -> { val p=a.toDouble(); val r=b.toDouble()/100; val t=c.toDouble(); val total=p*(1+r).pow(t); "Interest: ₹${total-p} | Total: ₹$total" }
                    "Date Difference" -> "${kotlin.math.abs(java.time.temporal.ChronoUnit.DAYS.between(LocalDate.parse(a),LocalDate.parse(b)))} days"
                    else -> "Unit converter: choose a conversion in a future update."
                }
            }.getOrElse { "Please check your inputs." }
            onResult(selected to answer)
        }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Blue)) { Text("CALCULATE") }
    }
}
