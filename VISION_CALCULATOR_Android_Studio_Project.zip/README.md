# VISION CALCULATOR

Native Android starter project built with Kotlin and Jetpack Compose.

## Included
- Basic arithmetic calculator with parentheses, percentage, sign toggle, delete and clear
- Scientific functions: trigonometry, log, ln, powers, roots, factorial, constants
- DEG/RAD toggle
- Local calculation history using DataStore
- Dark/light theme toggle
- Quick tools: percentage, GST, discount, age, EMI, simple interest, compound interest, date difference
- Offline operation; no permissions, login, ads or network dependency

## Build the APK
1. Install Android Studio (Ladybug or newer) and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For a signed release, select **Build > Generate Signed Bundle / APK** and follow the signing wizard.

Minimum Android version: Android 8.0 (API 26).

## Notes
This is a working starter implementation, not a prebuilt signed APK. The unit converter currently shows a placeholder. Voice input, floating window, formula library, share/copy actions and advanced scientific inverse-trig/fraction UI are not included in this first build. Validate financial calculations and edge cases before publishing.
